#pragma once

#include <opencv2\core\core.hpp>
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\imgproc\imgproc.hpp>
#include <opencv2\video\video.hpp>
#include <opencv2\video\background_segm.hpp>
#include <opencv2\video\tracking.hpp>
#include <vector>

using namespace cv;
using namespace std;

class Blob
{
public:
	Blob(void);
	~Blob(void);
	int ID;
	int firstFrameNumber;
	int lastFrameNumber;
	int frameCount;
	double avgWidth;
	double avgHeight;
	int maxWidth;
	int maxHeight;
	int collision;
	time_t startTime;
	time_t finishTime;

	//    cv::Point currentPosition;  
	cv::MatND currentHist;
	cv::Rect firstRectangle;
	cv::Rect lastRectangle;
	cv::Rect prevRectangle;

	std::vector<int> contactContours;
	cv::vector<cv::Mat> frames; //Danh sách các vùng ảnh ROI qua các frame
	cv::vector<cv::MatND> histograms;
	cv::vector<cv::Rect> rectsTrack;
};

