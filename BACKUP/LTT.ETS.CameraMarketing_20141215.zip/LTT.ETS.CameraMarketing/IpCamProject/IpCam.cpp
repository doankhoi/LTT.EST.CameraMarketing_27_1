#include "stdafx.h"
#include "ConnectDB.h"
#include "IpCam.h"


IpCam::IpCam(void)
{
	(this->db) = (this->connectDb).connectDb("database/MCAMClientCache.db3");
}


IpCam::~IpCam(void)
{
}


bool sortByFrameCount(const Blob &lhs, const Blob &rhs)
{
	return lhs.frameCount > rhs.frameCount;
}


string IpCam::intToString(int number) 
{
	stringstream ss;
	ss << number;
	return ss.str();
}

void IpCam::drawLine(cv::Mat &frame, cv::Point a, cv::Point b) 
{
	cv::line(frame, a, b, cv::Scalar(255, 0, 0), 2);
}

void IpCam::drawROI(cv::Mat &frame, vector<Point> v)
{
	int size = v.size();
	for(int i=1; i< size; i++){
		this->drawLine(frame, v[i-1], v[i]);
	}

	this->drawLine(frame, v[0], v[size-1]);
}

bool IpCam::checkCollisionRect(cv::Rect rect1, cv::Rect rect2)
{
	if ((std::max(rect1.x, rect2.x) <= std::min(rect1.x + rect1.width, rect2.x + rect2.width))&&
		(std::max(rect1.y, rect2.y) <= std::min(rect1.y + rect1.height, rect2.y + rect2.height))) {
			return true;
	} 
	return false;
}

void IpCam::trackCamshift(cv::Mat &image, cv::Rect initWindow, int vmin, int vmax, int smin, cv::Rect &rectOutput)
{
	cv::Rect trackWindow = initWindow;
	Mat hsv, hue, hist, histimg, mask, backproj;
	cv::cvtColor(image, hsv, COLOR_BGR2HSV);
	cv::inRange(hsv, Scalar(0, smin, MIN(vmin,vmax)), Scalar(180, 256, MAX(vmin, vmax)), mask);
	int ch[] = {0, 0};

	hue.create(hsv.size(), hsv.depth());
	mixChannels(&hsv, 1, &hue, 1, ch, 1);

	Mat roi(hue, trackWindow), maskroi(mask, trackWindow);
	int hsize = 16;
	float hranges[] = {0,180};
	const float* phranges = hranges;

	calcHist(&roi, 1, 0, maskroi, hist, 1, &hsize, &phranges);
	normalize(hist, hist, 0, 255, CV_MINMAX);
	histimg =  Mat::zeros(200, 320, CV_8UC3);

	histimg = Scalar::all(0);
	int binW = histimg.cols / hsize;

	Mat buf(1, hsize, CV_8UC3);

	for(int i = 0; i < hsize; i++ )
		buf.at<Vec3b>(i) = Vec3b(saturate_cast<uchar>(i*180./hsize), 255, 255);

	cvtColor(buf, buf, CV_HSV2BGR);

	/*for( int i = 0; i < hsize; i++ )
	{
	int val = saturate_cast<int>(hist.at<float>(i)*histimg.rows/255);
	rectangle( histimg, Point(i*binW,histimg.rows), Point((i+1)*binW,histimg.rows - val), Scalar(buf.at<Vec3b>(i)), -1, 8 );
	}*/

	calcBackProject(&hue, 1, 0, hist, backproj, &phranges);
	backproj &= mask;
	RotatedRect trackBox = CamShift(backproj, trackWindow, TermCriteria( CV_TERMCRIT_EPS | CV_TERMCRIT_ITER, 10, 1 ));

	if( trackWindow.area() <= 1 )
	{
		int cols = backproj.cols, rows = backproj.rows, r = (MIN(cols, rows) + 5)/6;

		trackWindow = Rect(trackWindow.x - r, trackWindow.y - r, trackWindow.x + r, trackWindow.y + r) &
			Rect(0, 0, cols, rows);
	}

	rectOutput = trackWindow;
}

void IpCam::run(string url)
{
	//Khai báo
	Mat element;
	Mat foregroundFrameBuffer, contoursFrame, roiFrameMask, roiFrame, roiFrameBuffer, rawFrame, rawCopyFrame, foregroundFrame;

	Mat binaryImg;

	Ptr<BackgroundSubtractor> mog;

	vector<vector<Point> > contours;
	vector<Vec4i> hierarchy;

	cv::TermCriteria criteria(cv::TermCriteria::MAX_ITER, 10, 0.01);

	(this->cap).open(url);

	if(!(this->cap).isOpened())
	{
		cout << "Error: Not connect to: " << url << endl;
		return;
	}

	//Danh sách các ứng cử viên
	vector<Blob> blobContainer;
	Rect boundingRectangle;

	//Danh sách các Blob người được vẽ trong vòng lặp trước
	vector<Blob> peopleContainerTrack;
	vector<Blob>::iterator it;
	vector<Blob>::iterator itBlobContainer;

	//----end khai báo
	mog = new BackgroundSubtractorMOG2(300, 32, true);//(300, 32, true)
	mog->set("nmixtures", 3);

	int frameNumber = 0;
	int numPeopleContainerTrack = 0;
	int numBlobOfRoi = 0;
	Utils utils;
	int ID = 0;
	time_t current;
	time(&current);
	int index = (this->connectDb).getNewstIdCustomer(this->db, SHOP_CD, current);

	//Giới hạn khung hình
	vector<Point> polyPointOfROI;

	SCALE_HEIGHT = 0.7;
	SCALE_WIDTH = 0.2;
	MY_THRESHOLD = 125;

	FRAME_WIDTH = cap.get(CV_CAP_PROP_FRAME_WIDTH)/3;
	FRAME_HEIGHT = cap.get(CV_CAP_PROP_FRAME_HEIGHT)/3;

	MIN_SCALE = std::max(FRAME_WIDTH, FRAME_HEIGHT) / 50;
	MAX_SCALE = std::max(FRAME_WIDTH, FRAME_HEIGHT) / 2;

	//Bốn điểm danh giới

	BOTTOM_LEFT = cv::Point( static_cast<int>(FRAME_WIDTH* SCALE_WIDTH)- 50, static_cast<int> (FRAME_HEIGHT * SCALE_HEIGHT));
	BOTTOM_RIGHT = cv::Point(FRAME_WIDTH - static_cast<int>(static_cast<int>(FRAME_WIDTH* SCALE_WIDTH)), static_cast<int> (FRAME_HEIGHT * SCALE_HEIGHT));

	TOP_LEFT = cv::Point(static_cast<int>(FRAME_WIDTH* SCALE_WIDTH)-50,static_cast<int>(FRAME_HEIGHT * 0.05));
	TOP_RIGHT = cv::Point(FRAME_WIDTH - static_cast<int>(static_cast<int>(FRAME_WIDTH* SCALE_WIDTH)), static_cast<int>(FRAME_HEIGHT * 0.05));

	polyPointOfROI.push_back(BOTTOM_LEFT);
	polyPointOfROI.push_back(BOTTOM_RIGHT);
	polyPointOfROI.push_back(TOP_RIGHT);
	polyPointOfROI.push_back(TOP_LEFT);

	//Vùng ảnh theo vết trong cửa hàng
	cv::Rect roi(TOP_LEFT.x, TOP_LEFT.y, TOP_RIGHT.x - TOP_LEFT.x, BOTTOM_LEFT.y - TOP_LEFT.y);

	//Vùng ảnh ngoai cửa hàng
	cv::Rect roiDetect( 0, BOTTOM_LEFT.y, FRAME_WIDTH, FRAME_HEIGHT - BOTTOM_LEFT.y);

	//----end lấy vùng ảnh quan trọng ---

	element = getStructuringElement(MORPH_RECT, Size(7, 7), Point(3, 3));
	//Ma tran loc
	cv::Mat element5(5, 5, CV_8U, cv::Scalar(1));

	while (true) {

		if (!(cap.read(rawFrame))) 
			break;

		frameNumber++;

		if (rawFrame.empty()) {
			std::cout << "Finish" << endl;
			return;
		}

		//Chuyển đổi kích thước
		resize(rawFrame, rawFrame, Size(FRAME_WIDTH, FRAME_HEIGHT));

		imshow("Cam", rawFrame);

		drawROI(rawFrame, polyPointOfROI);
		//Blur
		blur(rawFrame, rawFrame, Size(4, 4));

		//Binary
		mog->operator()(rawFrame, foregroundFrame, -1);

		//pre procesing
		morphologyEx(foregroundFrame, binaryImg, cv::MORPH_CLOSE, element5);
		threshold(binaryImg, binaryImg, 128, 255, CV_THRESH_BINARY);

		cv::imshow("Forebg", binaryImg);

		//Lấy ảnh hiện
		foregroundFrameBuffer = binaryImg.clone();

		//-----Đếm lại các đối tượng trong vùng cửa hàng -------
		numBlobOfRoi = utils.getNumBlob(foregroundFrameBuffer, roi, MIN_SCALE, MAX_SCALE);
		std::cout << "NumBlobOfRoi:" << numBlobOfRoi << endl;

		//-------End đếm lại các đối tượng trong vùng cửa hàng.

		//-----Kiểm tra nếu số người lớn số người theo vết thì tạo đối tượng theo vết mới 
		// và gán thời gian bằng khung hình lớn nhất trong peopleContainerTrack ---
		numPeopleContainerTrack = peopleContainerTrack.size();
		if((numBlobOfRoi > numPeopleContainerTrack)&&(numPeopleContainerTrack != 0))
		{
			Blob maxBlob = utils.getMaxRect(peopleContainerTrack);
			Blob addBlob;

			addBlob.ID = ID++;
			addBlob.lastFrameNumber = maxBlob.lastFrameNumber;
			addBlob.avgHeight = maxBlob.avgHeight;
			addBlob.avgWidth = maxBlob.avgWidth;
			addBlob.maxHeight = maxBlob.maxHeight;
			addBlob.maxWidth = maxBlob.maxWidth;
			addBlob.lastRectangle = maxBlob.lastRectangle;
			addBlob.startTime = maxBlob.startTime;
			addBlob.rectsTrack = maxBlob.rectsTrack;

			//Đẩy thêm vào danh sách người theo vết
			peopleContainerTrack.push_back(addBlob);
			std::cout << "Mot doi tuong moi tach ra trong cua hang" << endl;
		}

		//Kiểm tra nếu numPeopleContainerTrack = 0 và numBlobOfRoi !=0 thì bổ sung vào danh sách theo vết
		if((numBlobOfRoi != 0) && (numPeopleContainerTrack==0))
		{
			utils.addPeopleContainerTrack(peopleContainerTrack, foregroundFrameBuffer,roi, MIN_SCALE, MAX_SCALE, ID, frameNumber);
		}

		//-----End đẩy thêm người theo vết 

		//-------Theo vết các blob nằm trong cửa hàng thuộc danh sách peopleContainerTrack
		//Dự đoán khung hình với Camshift
		it = peopleContainerTrack.begin();
		while(it != peopleContainerTrack.end())
		{
			cv::Rect fRect;
			trackCamshift(rawFrame, it->lastRectangle, 34, 128, 27 ,fRect);
			cv::rectangle(rawFrame, it->lastRectangle, Scalar(0,0,255),1,8);

			//Kiểm tra người đó có ra khỏi cửa hàng hay không
			if(utils.isGoOut(it->lastRectangle, fRect, roi))
			{
				//Tính thời gian trong cửa hàng.
				time_t current;
				time(&current);
				
				
				double seconds = difftime(current, it->startTime);
				std::cout << "Time of Id = " << it->ID << " : " << seconds << endl;

				//Lưu thời gian vào database
				string prefix_customer_cd = (this->connectDb).createDateCustomerCd(it->startTime);
				string maKhachHang = (this->connectDb).createFormatCustomerId(SHOP_CD, prefix_customer_cd, index);
				string timein = (this->connectDb).convertTimeInOut(it->startTime);
				string timeout = (this->connectDb).convertTimeInOut(current);
				string camdate = (this->connectDb).createCAM_DATE(it->startTime);
				index++;

				(this->connectDb).insert_TB_CAM_MARKET_CSMR(this->db, SHOP_CD, camdate, maKhachHang, timein, timeout, seconds);

				//Bổ sung nó vào phần tử phát hiện ngoài cửa hàng.
				blobContainer.push_back(*it);
				std::cout << "Mot khach di ra ngoai cua hang" << endl;

				//Xóa khung hình khỏi danh sách theo vết
				it = peopleContainerTrack.erase(it);

			}else{
				//Cập nhật khung hình của lastRectangle
				it->prevRectangle = it->lastRectangle;
				it->lastRectangle = fRect;
				it->rectsTrack.push_back(fRect);

				//Vẽ hình theo vết
				//utils.drawTrack(rawFrame, *it, cv::Scalar(0,0,255));
				it++;
			}
		}
		//----end theo vết----

		//Phát hiện khung các đối tượng
		findContours(foregroundFrameBuffer, contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);

		//Xóa các khung hình trong cửa hàng
		utils.eraseContours(contours, roi);

		//Đánh dấu đối tượng đã được chọn hay chưa
		vector<int> contourTaken(contours.size(), 0);

		//Xóa bỏ các khung hình quá lâu trong blobContainer
		utils.eraseBlob(blobContainer, 1000);

		//Duyệt qua các ứng cử viên trong vòng lặp trước
		int blobContainerSize = blobContainer.size();
		int contoursSize = contours.size();

		for (size_t bli = 0; bli < blobContainerSize; bli++) {
			// Clean contact contours
			Blob blob = blobContainer[bli];
			blob.contactContours.clear();
			blob.collision = 0;

			//Duyệt qua danh sách
			for (size_t coi = 0; coi < contoursSize; coi++) {
				boundingRectangle = cv::boundingRect(contours[coi]);

				// Tìm khoảng cách gần nhất với ứng cử viên trong danh sách vòng lặp trước.
				double distance = sqrt(pow((blob.lastRectangle.x + blob.lastRectangle.width / 2.0)-(boundingRectangle.x + boundingRectangle.width / 2.0), 2.0) + pow((blob.lastRectangle.y + blob.lastRectangle.height / 2.0)-(boundingRectangle.y + boundingRectangle.height / 2.0), 2.0));

				// Nếu là hai khung hình liên tiếp và khoảng cách gần nhau thì đó là đối tượng của vòng lặp trước
				if (distance < min(blob.lastRectangle.width, blob.lastRectangle.height) &&
					(frameNumber - blob.lastFrameNumber == 1) && utils.checkRect(boundingRectangle, MIN_SCALE, MAX_SCALE)) {
						//Đánh dấu vị trí các ứng cử viên cho vị trí tiếp theo của BlobContainer[bli]
						blob.contactContours.push_back(coi);
				}
			}

		}

		// Sort blobContainer 
		if (blobContainerSize > 1)
			sort(blobContainer.begin(), blobContainer.end(), sortByFrameCount);

		// Tìm hình có diện tích lớn nhất trong các ứng cử viên của BlobContainer[bli]
		for (size_t bli = 0; bli < blobContainerSize; bli++) {
			int maxArea = 0;
			int selectedContourIndex = -1;
			Blob blob = blobContainer[bli];

			for (size_t cni = 0; cni < blob.contactContours.size(); cni++) {
				int coi = blob.contactContours[cni];
				int contourArea = cv::boundingRect(contours[coi]).width * cv::boundingRect(contours[coi]).height;
				if (contourArea > maxArea) {
					maxArea = contourArea;
					selectedContourIndex = coi;
				}
			}


			// Thêm vào danh sách
			if (selectedContourIndex != -1 && contourTaken[selectedContourIndex] == 0) {

				contourTaken[selectedContourIndex] = 1;
				//Lưu ứng cử viên có diện tích lớn nhất
				blob.contactContours.push_back(selectedContourIndex);

				//Lấy thuộc tính của hình có diện tích lớn nhất
				boundingRectangle = cv::boundingRect(Mat(contours[selectedContourIndex]));

				//Lưu lại vùng quan trọng.
				roiFrameMask = foregroundFrameBuffer(boundingRectangle).clone();
				roiFrame = foregroundFrameBuffer(boundingRectangle).clone();
				roiFrameBuffer = rawFrame(boundingRectangle).clone();

				//Chỉ lấy các điểm với mặt nạ roiFrameMask
				roiFrameBuffer.copyTo(roiFrame, roiFrameMask);

				//Tính histogram của ảnh.
				//MatND hist = colorHist.getHistogram(roiFrameBuffer, MY_THRESHOLD);

				// Cập nhật lại vị trí của blobContainer[bli]
				blob.frameCount++;
				blob.lastFrameNumber = frameNumber;
				blob.lastRectangle = boundingRectangle;
				blob.frames.push_back(roiFrameBuffer);

				blob.avgWidth = 0.8 * blob.avgWidth + 0.2 * roiFrame.size().width;
				blob.avgHeight = 0.8 * blob.avgHeight + 0.2 * roiFrame.size().height;

				blob.maxWidth = max(blob.maxWidth, roiFrame.size().width);
				blob.maxHeight = max(blob.maxHeight, roiFrame.size().height);

			}

			if (blob.contactContours.size() > 1) {
				blob.collision = 1;
			}

		}

		// Tìm đối tượng mới xuất hiện.   
		for (size_t coi = 0; coi < contoursSize; coi++) {
			boundingRectangle = cv::boundingRect(Mat(contours[coi]));

			//Nếu chiều dài hoặc chiều cao lớn hơn 1/50 khung hình thì coi là đối tượng.
			if (contourTaken[coi] == 0 && utils.checkRect(boundingRectangle, MIN_SCALE, MAX_SCALE)) {

				boundingRectangle = cv::boundingRect(contours[coi]);

				roiFrameMask = foregroundFrameBuffer(boundingRectangle).clone();
				roiFrame = foregroundFrameBuffer(boundingRectangle).clone();
				roiFrameBuffer = rawFrame(boundingRectangle).clone();
				roiFrameBuffer.copyTo(roiFrame, roiFrameMask);

				// Tạo đối tượng mới
				ID++;
				Blob newObject;
				newObject.ID = ID;
				newObject.frameCount = 1;
				newObject.firstFrameNumber = frameNumber;
				newObject.lastFrameNumber = frameNumber;
				newObject.firstRectangle = boundingRectangle;
				newObject.lastRectangle = boundingRectangle;
				newObject.frames.push_back(roiFrameBuffer);
				newObject.avgWidth = roiFrame.size().width;
				newObject.avgHeight = roiFrame.size().height;
				newObject.maxWidth = roiFrame.size().width;
				newObject.maxHeight = roiFrame.size().height;

				blobContainer.push_back(newObject);
				std::cout << "Moi bo sung doi tuong vao blobContainer" << endl;
			}
		}


		itBlobContainer = blobContainer.begin();
		while(itBlobContainer != blobContainer.end())
		{
			if(itBlobContainer->lastFrameNumber == frameNumber)
			{
				//Dự đoán khung hình tiếp theo của các ứng cử viên
				Rect rect;
				trackCamshift(rawFrame, itBlobContainer->lastRectangle, 34, 128, 27, rect);

				//Kiểm tra đối tượng có đi vào cửa hàng hay không
				if(utils.isGoIn(itBlobContainer->lastRectangle, rect,roi))
				{
					//Gắn thời gian đi vào cửa hàng
					time_t current;
					time(&current);

					itBlobContainer->startTime = current; 
					//Đẩy vào danh sách theo vết trong cửa hàng
					peopleContainerTrack.push_back(*itBlobContainer);

					std::cout << "Mot doi tuong moi vao cua hang" << endl;
					//Loại bỏ khung hình này ngoài cửa hàng
					itBlobContainer = blobContainer.erase(itBlobContainer);
					continue;

				}else{
					itBlobContainer++;
				}
			}else{
				itBlobContainer++;
			}
		}

		//for (size_t bli = 0; bli < blobContainerSize; bli++) {
		//	Blob blob = blobContainer[bli];
		//	if ((blob.lastFrameNumber == frameNumber) && (blob.frameCount > 5)) {

		//		//Dự đoán khung hình tiếp theo của khung hình trong blobContainer
		//		Blob blob;
		//		Rect rect;
		//		blob = blobContainer[bli];
		//		trackCamshift(rawCopyFrame, blob.lastRectangle, 34, 128, 27 ,rect);

		//		//Kiểm tra đối tượng có đi vào cửa hàng hay không
		//		if(utils.isGoIn(blob.lastRectangle, rect, roi))
		//		{
		//			//Loại bỏ khỏi danh sách ứng cử viên ngoài cửa hàng

		//		}
		//		//----End dự đoán khung hình ---


		//		//Ghi tao do cua vung len anh
		//		int x = blobContainer[bli].lastRectangle.x;
		//		int y = blobContainer[bli].lastRectangle.y;

		//		//Kiểm tra độ rộng của khung hình (dự đoán người)
		//		cout << "Do rong khung hinh: " << blobContainer[bli].ID << " v " << blobContainer[bli].avgWidth << endl; 

		//		//Tính thời gian đã qua của đối tượng
		//		time_t current;
		//		time(&current);

		//		double seconds = difftime(current, blobContainer[bli].startTime);

		//		//------------------------
		//		string text("(" + intToString(x) + "," + intToString(y) + "):" + intToString(blobContainer[bli].ID) + ":" + intToString(seconds));

		//		int fontFace = FONT_HERSHEY_COMPLEX_SMALL;
		//		double fontScale = 0.5;
		//		int thickness = 1;
		//		cv::Point textOrg(x, y);
		//		cv::putText(rawFrame, text, textOrg, fontFace, fontScale, Scalar(0, 0, 255, 255), thickness);

		//		//Đẩy vào danh sách người theo vết nếu khung hình nằm trong cửa hàng
		//		if(isIn(blobContainer[bli].lastRectangle))
		//		{
		//			peopleContainerTrack.push_back(blobContainer[bli]);
		//		}
		//		else//Nằm ngoài cửa hàng
		//		{

		//		}

		//		rectangle(rawFrame, blobContainer[bli].lastRectangle, CV_RGB(0, 0, 255));
		//		
		//	}
		//}


		std::cout << "Gia tri blobContainer:" << blobContainer.size() << endl;
		std::cout << "Gia tri cua peopleContainerTrack: " << peopleContainerTrack.size() << endl;
		//cv::imshow("Frame", rawFrame);     
		if (waitKey(10) > 0) {
			break;
		}
	}

	this->cap.release();

}