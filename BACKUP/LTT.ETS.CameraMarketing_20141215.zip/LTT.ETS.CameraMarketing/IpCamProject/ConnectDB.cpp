#include "stdafx.h"
#include "ConnectDB.h"


ConnectDB::ConnectDB(void)
{
}


ConnectDB::~ConnectDB(void)
{
}

string ConnectDB::normalizationIndexCsmrId(int index)
{
	char intstr[5];
	_itoa_s(index, intstr, 10);
	int str_length = string(intstr).length();
	char temp[5];
	for(int i = 0; i < 5; i++){
		if(i >= 5 - str_length) {
			int j = i - (5 - str_length);
			temp[i] = intstr[j]; 
		} else {
			temp[i] = '0';
		}
	}
	string id = string(temp);
	return id;
}

string ConnectDB::createCAM_DATE(time_t time)
{
	struct tm timeinfo;
	localtime_s(&timeinfo, &time); //convert it to tm

	char t_CAM_DATE[8];
	const char c_CamDate[] = "%y%m%d";

	if (strftime(t_CAM_DATE, sizeof(t_CAM_DATE) - 1, c_CamDate, &timeinfo)>0) {
		return string(t_CAM_DATE);
	}
	else
		return NULL;
}

sqlite3* ConnectDB::connectDb(const char* path)
{
	sqlite3 *db;
	char *zErrMsg = 0;
	int rc;
	char *sql = (char*)malloc(sizeof(char)*500);
	//sqlite3_stmt *statement;

	rc = sqlite3_open(path, &db);
	if(rc){
		printf("SQL err: %d-- %s\n", rc, zErrMsg);
		sqlite3_close(db);
		return NULL;
	}
	else{
		printf("Opened successful! \n");   
		return db;
	}
}

string ConnectDB::convertTimeInOut(time_t t)
{
	struct tm timeinfo;
	localtime_s(&timeinfo, &t); //convert it to tm

	char t_IN[21];
	const char c_InOut[]="%Y-%m-%d %H:%M:%S";

	if (strftime(t_IN, sizeof(t_IN)-1, c_InOut, &timeinfo)>0) {
		cout<<t_IN<< endl;
		return string(t_IN);
	}
	else 
		return NULL;
}
string ConnectDB::createDateCustomerCd(time_t t)
{
	struct tm timeinfo;
	localtime_s(&timeinfo, &t); //convert it to tm

	char t_prefix[6];
	const char c[] = "%y%m";

	if (strftime(t_prefix, sizeof(t_prefix) - 1, c, &timeinfo)>0) {
		
		return string(t_prefix);
	}
	else
		return NULL;
}


int ConnectDB::getNewstIdCustomer(sqlite3* db, string soHieuCuaHang, time_t t)
{

	struct tm timeinfo;
	localtime_s(&timeinfo, &t); //convert it to tm

	char time[6];
	const char c[] = "%m%Y";
	strftime(time, sizeof(time) - 1, c, &timeinfo);

	char *sql = new char[500];
	sqlite3_stmt *statement;

	sprintf(sql, "select CAM_CSMR_CD from TB_CAM_MARKET_CSMR where SHOP_CD = '%s' and CAM_DATE = '%s';", soHieuCuaHang.c_str(), string(time).c_str());

	cout << sql <<endl;
	int current_index = 0;

	if ( sqlite3_prepare(db, sql, -1, &statement, 0 ) == SQLITE_OK ) {
		int res = 0;
		while ( 1 ) {
			res = sqlite3_step(statement);
			if ( res == SQLITE_ROW ) {          
				string s = (char*)sqlite3_column_text(statement, 0);
				s = s.substr(9,5);
				int s_int = atoi(s.c_str());
				if(s_int >= current_index) current_index = s_int;
			} 
			if ( res == SQLITE_DONE || res==SQLITE_ERROR) {
				break;
			}    
		}
	}

	return current_index + 1;
}

string ConnectDB::createFormatCustomerId(string maCuaHang, string thoiGian, int index)
{
	string current_index_string = normalizationIndexCsmrId(index);  // có dạng 00004
	string CSMR_ID;
	CSMR_ID.append(maCuaHang);
	CSMR_ID.append(thoiGian);
	CSMR_ID.append(current_index_string);
	cout << CSMR_ID << endl;

	return CSMR_ID;
}

bool ConnectDB::insert_TB_CAM_MARKET_CSMR(sqlite3* db, string maCuaHang, string thoiGianCamDate, string maKhach, string timeIn, string timeOut, int timeOn)
{
	char *sql = new char[500];
    sqlite3_stmt *statement;
	sprintf(sql, 
		"INSERT INTO TB_CAM_MARKET_CSMR (SHOP_CD , CAM_DATE, CAM_CSMR_CD, TIME_IN, TIME_OUT, TIME_IN_SHOP, SYNCHRONIZED)VALUES ('%s','%s', '%s', '%s', '%s', '%d', 0);", 
		maCuaHang.c_str(), thoiGianCamDate.c_str(), maKhach.c_str(), timeIn.c_str(), timeOut.c_str(), timeOn); 

	if ( sqlite3_prepare(db, sql, -1, &statement, 0 ) == SQLITE_OK ) 
	{
		return true;
	}

	return false;
}
