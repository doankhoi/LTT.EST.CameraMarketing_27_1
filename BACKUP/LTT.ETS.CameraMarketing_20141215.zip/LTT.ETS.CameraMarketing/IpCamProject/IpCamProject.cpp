// IpCamProject.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include "IpCam.h"
using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	IpCam ipCam;
	ipCam.run("http://tendo1050:mf2CWYIG8w@www.i-mcs-ytd.com:57251/video3.mjpg");
	return 0;
}

