#include "stdafx.h"
#include "ColorHistogram.h"


ColorHistogram::ColorHistogram(void)
{
	histSize[0] = histSize[1] = histSize[2] = 256;
	hranges[0] = 0.0f;
	hranges[1] = 256.0f;

	ranges[0] = hranges;
	ranges[1] = hranges;
	ranges[2] = hranges;

	chanels[0] = 0;
	chanels[1] = 1;
	chanels[2] = 2;
}

ColorHistogram::~ColorHistogram(void)
{
}

MatND ColorHistogram::getHistogram(const Mat& image){
    MatND hist;
    calcHist(&image, 1, chanels, Mat(), hist, 3, histSize, ranges);
    
    return hist;
}

MatND ColorHistogram::getHistogram(const Mat& image, int minSat=0){
    MatND hist;
    //Chuyen doi RBG sang HUE
    Mat hsv;   
    cvtColor(image, hsv, CV_RGB2HSV);
    
    //Kiem tra minSat cua anh
    Mat mask;
    if(minSat > 0){
        vector<Mat> v;
        split(hsv, v); //Tach ra 3 anh       
        threshold(v[1], mask, minSat, 255, CV_THRESH_BINARY);
    }
    
    hranges[0] = 0.0f;
    hranges[1] = 180.0f;
    chanels[0]=0;
    
    calcHist(&hsv, 1, chanels, mask, hist, 1, histSize, ranges);
    
    return hist;
}
