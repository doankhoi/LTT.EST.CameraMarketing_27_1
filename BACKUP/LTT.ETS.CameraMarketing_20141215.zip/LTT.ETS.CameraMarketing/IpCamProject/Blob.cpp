#include "stdafx.h"
#include "Blob.h"


Blob::Blob(void)
{
}


Blob::~Blob(void)
{
}
